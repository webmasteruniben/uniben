<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <style>
        .bg{
        background-image: url("asset/images/gate2.png");
        background-repeat: no-repeat;
        height: 100%;
        padding-top: 170px;
        padding-bottom: 40px;
       
        }
        

        h1{
            color:#fff;
        }
        .map{
           
            margin-top: 50px;
            border-radius: 15px;
            margin: 40px auto auto auto;
            overflow: hidden;
        }
        .contactForm{
            border: 1px solid #9C0C84;
            margin-top: 50px;
            border-radius: 15px;
            margin: 40px auto auto auto;
            color:#fff;
            background-color: #9C0C84;
           /*width: 60%;
            padding: 20px*/
        }
        .btn {
            width: 100%;
            background-color: #91048C;
            margin-bottom: 5px;
        }
        ul {
            list-style-type:none;
        }
        .row{
            margin: 10px;
        }
        .address{
            float: right;
        }
        
        .item{
            text-decoration: none;
            font-size: 16px;
            color: #fff;
        }
        img{
            height: 30px;
            width: 30px;

        }

        .images img{
            margin-left: 20px;
            border: 1px solid green;
            border-radius: 7px;
            overflow: hidden;
           transition: all 0.3s ease;

        }
        .images img:hover{
            height: 40px;
            width: 40px;
        }
        
    </style>
</head>
<body>
   <div class="bg">
    <div class="container">
        <div class="row">
        
            <div class="col-sm-offset-1 col-6 contactForm">
                <h1><bold>Contact us:</bold></h1>
            
                <?php
                    include 'contactretrival.php';
                ?>
        

                <form action="contactus.php" method="post">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" name="name" value="<?php echo $name?>" id="name" placeholder="Name" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" name="email" value="<?php echo $email?>" id="email" placeholder="Email" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="messages">Message:</label>
                        <textarea name="messages" id="messages" class="form-control" rows="5" placeholder="Message"><?php echo $messages?></textarea>
                    </div>
                    <input type="submit" name="submit" value="Send message" id="submit" class="btn btn-success btn-lg">
                </form>
            </div>
            <div class="col-lg-offset-1 col-6 map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63442.93369776195!2d5.579885213616445!3d6.370312722606933!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1040d3014e1c75cf%3A0x5f3cd0b086c0e598!2sUniversity%20of%20Benin!5e0!3m2!1sen!2sng!4v1599746459466!5m2!1sen!2sng" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>             
        </div>
        <div class="row">
                
                <ul class=" col-lg-offset-1 col-4 address">
  <li class="item"><img src="asset/images/box9.png">P.M.B. 1154, Ugbowo, Benin city, Edo state.</li>
  </ul>
  <ul class=" col-lg-offset-1 col-3 phone">
  <li class="item"><img src="asset/images/phoneicon.png">07025004748, 09155660000</li>
  </ul>
  <ul class=" col-lg-offset-1 col-5 images">
  <!--<li class="item"><a href="info@uniben.edu" target="#"><img src="asset/images/gmailicon.png" alt="Email Us"></a>-->
  <a href="https://twitter.com/UniversityofBen" target="#"><img src="asset/images/twittericon.png" alt="Our Twitter Handle"></a>
  <a href="https://www.facebook.com/greatuniben" target="#"><img src="asset/images/facebook.png" alt="Our Facebook Page"></a>
  <a href="https://www.linkedin.com/school/university-of-benin/" target="#"><img src="asset/images/li3.jpg" alt="Our Linkendin Page"></a>
  <a href="https://www.youtube.com/user/unibenwebmaster/videos" target="#" ><img src="asset/images/youtubeicon2.png" alt="Our Youtube Chanell"></a></li>
  </ul>
               
        </div>
    </div>
    </div>
    
    <script>
       src =  "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</body>
</html>